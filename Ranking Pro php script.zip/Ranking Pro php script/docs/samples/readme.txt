SAMPLES
-------

Currently we do not have sample HTML setups available.  When they do
become available in the next few weeks, we will post them in the owners 
lounge and add them to the AutoRank Pro distribution.  In the meantime 
if you have questions about setting up the HTML for your list, you can
post a message to the help board in the owners lounge and we will try
to assist you.  Note that we are not HTML experts, so there are some
HTML issues we may not be able to help you with.  If you are doing very
advanced HTML, you will probably be on your own.
